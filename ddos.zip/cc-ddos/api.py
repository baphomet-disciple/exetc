from flask import Flask
from subprocess import Popen, PIPE

app = Flask(__name__)

@app.route('/run/<website>')
def run(website):
    print(f"https://{website}")
    process = Popen(['python3', 'dos.py', f'https://{website}'], stdout=PIPE, stderr=PIPE)
    stdout, stderr = process.communicate()
    if process.returncode != 0:
        return stderr.decode('utf-8'), 500
    return stdout.decode('utf-8')

if __name__ == '__main__':
    app.run(port=3001)
